<?php
namespace Rsgitech\News\Block\Adminhtml\Allnews;

class Grid extends \Magento\Backend\Block\Widget\Grid
{
 
}
?>
