<?php
namespace Admin\Grid\Ui\DataProvider;

use Magento\Ui\DataProvider\AbstractDataProvider;
use Admin\Grid\Model\ResourceModel\Grid\CollectionFactory;
use Magento\Framework\App\RequestInterface;

class FormDataProvider extends AbstractDataProvider
{
    protected $loadedData;
    protected $request; // Store request object

    public function __construct(
        $name,
        $primaryFieldName,
        $requestFieldName,
        CollectionFactory $collectionFactory,
        RequestInterface $request, // Inject request here
        array $meta = [],
        array $data = []
    ) {
        $this->collection = $collectionFactory->create();
        $this->request = $request; // Assign to property
        parent::__construct($name, $primaryFieldName, $requestFieldName, $meta, $data);
    }

    public function getData()
    {
        if (isset($this->loadedData)) {
            return $this->loadedData;
        }

        $id = $this->request->getParam('entity_id'); // Directly using parameter name
        if ($id) {
            $item = $this->collection->getItemById($id);
            if ($item) {
                $this->loadedData[$id] = $item->getData();
            }
        }

        return $this->loadedData ?? [];
    }
}
